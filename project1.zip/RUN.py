from ApplicationMain import *

app = ApplicationMain()
app.show_mainwindow()


app.run()