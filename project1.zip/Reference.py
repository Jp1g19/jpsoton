from library import *


class Reference:

    def __init__(self):
        self.root_ref = Tk()
        self.root_ref.geometry("700x120+20+550")
        self.root_ref.title("References")

    def run(self):
        self.root_ref.mainloop()

    def show_refwindow(self):
        self.root_ref.configure(bg='#E3FFFD')

        self.ref_title = Label(self.root_ref, text='Here are some links', bg='#E3FFFD', fg='#45A7A2',
                          font=('Cambria', 12)).place(x=280, y=5)

        self.Link1 = Label(self.root_ref,
                      text='https://d6s74no67skb0.cloudfront.net/course-material/EE601-Basic-Electrical-and-DC-Theory.pdf',
                      bg='#E3FFFD', fg='#45A7A2', cursor='hand2')
        self.Link1.place(x=30, y=30)
        self.Link1.bind("<Button-1>", lambda e: webbrowser.open(self.Link1.cget("text")))

        self.Link2 = Label(self.root_ref,
                      text='https://blackboard.soton.ac.uk/webapps/blackboard/content/listContent.jsp?course_id=_189678_1&content_id=_4253541_1',
                      bg='#E3FFFD', fg='#45A7A2', cursor='hand2')
        self.Link2.place(x=30, y=55)
        self.Link2.bind("<Button-1>", lambda e: webbrowser.open(self.Link2.cget("text")))
        self.button_exit_ref = Button(self.root_ref, text='Exit', bg='#85E8E1', fg='white', font=('Fixedsys', 5),
                                 command=self.exit).place(
            x=330, y=85)

    def exit(self):
        self.root_ref.destroy()