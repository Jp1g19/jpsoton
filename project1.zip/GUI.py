from library import *


class GUI:
    width_res = 10
    height_res = 20
    def __init__(self,number,a, voltage, isparallel, current, message):
        self.root_gui = Tk()
        self.number = number
        self.a = a
        self.voltage = voltage
        self.isparallel = isparallel
        self.current = current
        self.message = message
        self.canvas = Canvas(self.root_gui, width=550, height=500)


    def run(self):
        self.create_curcuit()
        self.canvas.create_text(250, 350, fill="darkblue", font="Times 20 italic bold",
                                text=self.message)
        self.canvas.pack()
        self.root_gui.mainloop()

    def create_curcuit(self):
        if self.number == 1:
            self.create_res(50)
            self.canvas.pack()
            return
        self.canvas.create_line(150, 50, 150, 200)
        self.canvas.create_line(400, 50, 400, 200)
        if self.number == 2:
            self.create_res(50)
            self.create_res(200)
        elif self.number == 3:
            self.create_res(125)
            self.create_res(50)
            self.create_res(200)
        elif self.number == 4:
            self.create_res(50)
            self.create_res(200)
            self.create_res(100)
            self.create_res(150)

        self.canvas.pack()

    def create_res(self, height):
        self.canvas.create_line(150, height, 250, height)
        self.canvas.create_line(300, height, 400, height)
        self.canvas.create_rectangle(250, height-15, 300, height+15, outline="#fb0", fill="#1f1")
        self.canvas.pack()




    def create_series(self):
        self.canvas.create_line(150, 50, 400, 50)

        if self.number == 1:
            self.create_res_series(50)
            self.canvas.pack()
            return
        if self.number == 2:
            self.create_res_series(50)
            self.create_res_series(200)
        elif self.number == 3:
            self.create_res_series(125)
            self.create_res_series(50)
            self.create_res_series(200)
        elif self.number == 4:
            self.create_res_series(50)
            self.create_res_series(200)
            self.create_res_series(100)
            self.create_res_series(150)

        self.canvas.pack()

    def create_res_series(self, width):
        self.canvas.create_line(150, width, 250, width)
        self.canvas.create_line(300, width, 400, width)
        self.canvas.create_rectangle(250, width-15, 300, width+15, outline="#fb0", fill="#1f1")
        self.canvas.pack()



