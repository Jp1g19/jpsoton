from ApplicationCalc import *
from Reference import *
from DCtheory import *

class ApplicationMain:
    def __init__(self):
        self.root = Tk()
        self.root.geometry("450x550+470+200")
        self.root.title("DC Simulator")

    def run(self):
        self.root.mainloop()

    def create_calcwindow(self):
        self.calcwindow = ApplicationCalc()
        self.calcwindow.show_calcwindow()
        self.calcwindow.run()
    def create_refwindow(self):
        self.refwindow = Reference()
        self.refwindow.show_refwindow()
        self.refwindow.run()

    def create_dcwindow(self):
        self.dctheorywindow = DCtheory()
        self.dctheorywindow.show_dcwindow()
        self.dctheorywindow.run()


    def show_mainwindow(self):
        self.mycolor = '#E3FFFD'

        self.root.configure(bg=self.mycolor)

        self.label_main_title = Label(self.root, text='Welcome to the DC Simulator!', bg='#E3FFFD', fg='#45A7A2',
                                 font=('Cambria', 18)) .place(x=70, y=60)

        self.label_theory = Label(self.root, text='Click here to learn about DC circuit theory!', bg='#E3FFFD', fg='#45A7A2',
                             font=('Cambria', 12)).place(x=65, y=215)

        self.label_calc = Label(self.root, text='Stuck on a problem ?\nClick here to get some help!', bg='#E3FFFD', fg='#45A7A2',
                           font=('Cambria', 12)).place(x=130, y=345)


        self.button_calc = Button(self.root, text='CALCULATOR', bg='#85E8E1', fg='white', font=('Fixedsys', 15),
                             command=self.create_calcwindow).place(
            x=170,
            y=400)

        self.button_exit = Button(self.root, text='Exit', bg='#85E8E1', fg='white', font=('Fixedsys', 15), command=exit).place(
            x=400,
            y=520)
        self.label_references = Label(self.root, text='Want to know more ?\nClick                to see our references!',
                                 bg='#E3FFFD',
                                 fg='#45A7A2', font=('Cambria', 12)).place(x=10, y=495)
        self.button_ref = Button(self.root, text='Here', bg='#85E8E1', fg='white', font=('Fixedsys', 1), command=self.create_refwindow, padx=5,
                            pady=1).place(x=51, y=520)
        self.button_theory = Button(self.root, text='DC THEORY', bg='#85E8E1', fg='white', font=('Fixedsys', 15),
                               command=self.create_dcwindow).place(x=170,
                                                 y=248)