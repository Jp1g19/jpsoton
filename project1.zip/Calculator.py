from library import *
from GUI import *


class Calculator:
    def __init__(self):
        self.var_s = False
        self.var_p = False
        self.var1 = 0

    def result(self, entry_r2, entry_r2_1, entry_r3, entry_r3_1,  entry_r3_2, entry_r4, entry_r4_1, entry_r4_2, entry_r4_3, entry2, entry_total_resistance, entry_total_current):
        #try:
        print(self.var_p, self.var_s)
        if (self.var_p and self.var_s) or (not self.var_p and not self.var_s):
            messagebox.showinfo('Error', 'Choose either parallel OR series')
            self.var_p = False
            self.var_s = False
            return

        if entry2.get() == '' and self.var1 == False:
            if 0.0 < float(entry_total_current.get()) < 10000.0 and 0.0 < float(
                    entry_total_resistance.get()) < 10000.0:
                current = float(entry_total_current.get())
                resistance = float(entry_total_resistance.get())
                voltage = round(current * resistance, 2)
                power = round(voltage ** 2 / resistance, 3)

                window = GUI(1, [resistance], voltage, True,  current, 'Voltage = ' + str(voltage) + '\n' + 'Total power = ' + str(power))
                window.run()
            else:
                messagebox.showinfo('RESULT', 'Error')


        elif entry_total_resistance.get() == '' and self.var1 == False:
            if 0.0 < float(entry_total_current.get()) < 10000.0 and 0.0 < float(entry2.get()) < 10000.0:
                current = float(entry_total_current.get())
                voltage = float(entry2.get())
                resistance = round(voltage / current, 3)
                power = round(voltage ** 2 / resistance, 3)
                #messagebox.showinfo('RESULT',
                                    #'Resistance =  ' + str(resistance) + '\n' + 'Total power = ' + str(power))
                window = GUI(1, [resistance], voltage, True,  current, 'Resistance =  ' + str(resistance) + '\n' + 'Total power = ' + str(power) )
                window.run()
            else:
                messagebox.showinfo('RESULT', 'Error7')

        elif entry_total_current.get() == '' and self.var1 == False:
            if 0.0 < float(entry_total_resistance.get()) < 10000.0 and 0.0 < float(entry2.get()) < 10000.0:
                resistance = float(entry_total_resistance.get())
                voltage = float(entry2.get())
                current = round(voltage / resistance, 3)
                power = round(voltage ** 2 / resistance, 3)
                window = GUI(1, [resistance], voltage, True,  current, 'Current = ' + str(current) + '\n' + 'Total power = ' + str(power))
                window.run()
            else:
                messagebox.showinfo('RESULT', 'Error')


        # FOR SERIES CIRCUIT
        elif self.var_s == True and self.var1 == 2 and self.var_p == False:
            if float(entry2.get()) <= 10000.0:
                v1 = float(entry2.get())
                r1_2 = float(entry_r2.get())
                r2_2 = float(entry_r2_1.get())
                rt = round(r1_2 + r2_2, 3)
                i2 = v1 / rt
                i2 = round(i2, 3)
                vr1_2 = round(i2 * r1_2, 3)
                vr2_2 = round(i2 * r2_2, 3)
                power = round(v1 ** 2 / rt, 3)
                window = GUI(2, [r1_2, r2_2], v1, False,  i2, 'Current = ' + str(
                    'R(total) = ' + str(rt) + '\n' + 'I(supply) = ' + str(i2) + '\n' + 'V(across R1) = ' + str(
                        vr1_2) + '\n' + 'V(across R2) = ' + str(
                        vr2_2) + '\n' + 'Total power = ' + str(power)))
                window.run()


        elif self.var_s == True and self.var1 == 3 and self.var_p == False:
            if float(entry2.get()) <= 10000.0:
                v1 = float(entry2.get())
                r1_3 = float(entry_r3.get())
                r2_3 = float(entry_r3_1.get())
                r3_3 = float(entry_r3_2.get())
                rt = round(r1_3 + r2_3 + r3_3, 3)
                i3 = v1 / rt
                i3 = round(i3, 3)
                vr1_3 = round(i3 * r1_3, 3)
                vr2_3 = round(i3 * r2_3, 3)
                vr3_3 = round(i3 * r3_3, 3)
                power = round(v1 ** 2 / rt, 3)
                window = GUI(3, [r1_3, r2_3, r3_3], v1, False,  i3, str(
                    'R(total) = ' + str(rt) + '\n' + 'I(supply) = ' + str(i3) + '\n' + 'V(across R1) = ' + str(
                        vr1_3) + '\n' + 'V(across R2) = ' + str(
                        vr2_3) + '\n' + 'V(across R3) = ' + str(vr3_3) + '\n' + 'Total power = ' + str(power)))
                window.run()



        elif self.var_s == True and self.var1 == 4 and self.var_p == False:
            if float(entry2.get()) <= 10000.0:
                v1 = float(entry2.get())
                r1_4 = float(entry_r4.get())
                r2_4 = float(entry_r4_1.get())
                r3_4 = float(entry_r4_2.get())
                r4_4 = float(entry_r4_3.get())
                rt = round(r1_4 + r2_4 + r3_4 + r4_4, 3)
                i4 = v1 / rt
                i4 = round(i4, 3)
                vr1_4 = round(i4 * r1_4, 3)
                vr2_4 = round(i4 * r2_4, 3)
                vr3_4 = round(i4 * r3_4, 3)
                vr4_4 = round(i4 * r4_4, 3)

                power = round(v1 ** 2 / rt, 3)
                window = GUI(4, [r1_4, r2_4, r3_4, r4_4], v1, False,  i4, str(
                    'R(total) = ' + str(rt) + '\n' + 'I(supply) = ' + str(i4) + '\n' + 'V(across R1) = ' + str(
                        vr1_4) + '\n' + 'V(across R2) = ' + str(
                        vr2_4) + '\n' + 'V(across R3) = ' + str(vr3_4) + '\n' + 'V(across R4) = ' + str(
                        vr4_4) + '\n' + 'Total power = ' + str(power)))
                window.run()

        # FOR PARALLEL CIRCUIT
        elif self.var_p == True and self.var1 == 2 and self.var_s == False:
            if float(entry2.get()) <= 10000.0:
                v1 = float(entry2.get())
                r1 = float(entry_r2.get())
                r1_1 = float(entry_r2_1.get())
                rt = round(((r1 * r1_1) / (r1 + r1_1)), 3)
                rt = round(rt, 3)
                ir1 = round(v1 / r1, 3)
                ir2 = round(v1 / r1_1, 3)
                it = ir1 + ir2
                power = round(v1 ** 2 / rt, 3)
                window = GUI(2, [r1, r1_1], v1, True,  it,  str(
                    'R(total) = ' + str(rt) + '\n' + 'I(across R1) = ' + str(ir1) + '\n' + 'I(across R2) = ' + str(
                        ir2) + '\n' + 'Total power = ' + str(power)))
                window.run()






        elif self.var_p == True and self.var1 == 3 and self.var_s == False:
            if float(entry2.get()) <= 10000.0:
                v1 = float(entry2.get())
                r1 = float(entry_r3.get())
                r1_1 = float(entry_r3_1.get())
                r1_2 = float(entry_r3_2.get())
                rt = round((1 / r1 + 1 / r1_1 + 1 / r1_2) ** -1, 3)
                rt = round(rt, 3)
                ir1 = round(v1 / r1, 3)
                ir2 = round(v1 / r1_1, 3)
                ir3 = round(v1 / r1_2, 3)
                it = ir1 + ir2 + ir3
                power = round(v1 ** 2 / rt, 3)
                window = GUI(3, [r1, r1_1, r1_2], v1, True,  it, str(
                    'R(total) = ' + str(rt) + '\n' + 'I(across R1) = ' + str(ir1) + '\n' + 'I(across R2) = ' + str(
                        ir2) + '\n' + 'I(across R3) = ' + str(ir3) + '\n' + 'Total power = ' + str(power)))
                window.run()



        elif self.var_p == True and self.var1 == 4 and self.var_s == False:
            if float(entry2.get()) <= 10000.0:
                v1 = float(entry2.get())
                r1 = float(entry_r4.get())
                r1_1 = float(entry_r4_1.get())
                r1_2 = float(entry_r4_2.get())
                r1_3 = float(entry_r4_3.get())
                rt = round((1 / r1 + 1 / r1_1 + 1 / r1_2 + 1 / r1_3) ** -1, 3)
                rt = round(rt, 3)
                ir1 = round(v1 / r1, 3)
                ir2 = round(v1 / r1_1, 3)
                ir3 = round(v1 / r1_2, 3)
                ir4 = round(v1 / r1_3, 3)
                it = ir1 + ir2 + ir3 + ir4
                power = round(v1 ** 2 / rt, 3)
                window = GUI(4, [r1, r1_1, r1_2, r1_3], v1, True,  it, str(
                    'R(total) = ' + str(rt) + '\n' + 'I(across R1) = ' + str(ir1) + '\n' + 'I(across R2) = ' + str(
                        ir2) + '\n' + 'I(across R3) = ' + str(ir3) + '\n' + 'I(across R4) = ' + str(
                        ir4) + '\n' + 'Total power = ' + str(power)))
                window.run()



        else:
            messagebox.showinfo('Error', 'Invalid data')

        self.var_p = False
        self.var_s = False

        #except Exception:
            #messagebox.showinfo('Result', 'Error')
