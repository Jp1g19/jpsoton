from Calculator import *

class ApplicationCalc:
    def __init__(self):
        self.root1 = Tk()
        self.root1.geometry("350x350+20+80")
        self.root1.title("Calculator")
        self.calc = Calculator()

    def run(self):
        self.root1.mainloop()

    def tick_func0(self):
            self.calc.var1 = 0
            self.label_r2.place_forget()
            self.label_r2_1.place_forget()

            self.entry_r2.place_forget()
            self.entry_r2_1.place_forget()

            self.label_r3.place_forget()
            self.label_r3_1.place_forget()
            self.label_r3_2.place_forget()

            self.entry_r3.place_forget()
            self.entry_r3_1.place_forget()
            self.entry_r3_2.place_forget()

            self.label_r4.place_forget()
            self.label_r4_1.place_forget()
            self.label_r4_2.place_forget()
            self.label_r4_3.place_forget()

            self.entry_r4.place_forget()
            self.entry_r4_1.place_forget()
            self.entry_r4_2.place_forget()
            self.entry_r4_3.place_forget()

    def tick_func2(self):
            self.calc.var1 = 2
            self.label_r2.place(x=80, y=80)
            self.label_r2_1.place(x=180, y=80)
            self.entry_r2.place(x=120, y=80)
            self.entry_r2_1.place(x=220, y=80)

            self.label_r3.place_forget()
            self.label_r3_1.place_forget()
            self.label_r3_2.place_forget()

            self.entry_r3.place_forget()
            self.entry_r3_1.place_forget()
            self.entry_r3_2.place_forget()

            self.label_r4.place_forget()
            self.label_r4_1.place_forget()
            self.label_r4_2.place_forget()
            self.label_r4_3.place_forget()

            self.entry_r4.place_forget()
            self.entry_r4_1.place_forget()
            self.entry_r4_2.place_forget()
            self.entry_r4_3.place_forget()


    def tick_func3(self):
            self.calc.var1 = 3
            self.label_r3.place(x=50, y=80)
            self.label_r3_1.place(x=140, y=80)
            self.label_r3_2.place(x=230, y=80)
            self.entry_r3.place(x=90, y=80)
            self.entry_r3_1.place(x=180, y=80)
            self.entry_r3_2.place(x=270, y=80)

            self.label_r2.place_forget()
            self.label_r2_1.place_forget()

            self.entry_r2.place_forget()
            self.entry_r2_1.place_forget()

            self.label_r4.place_forget()
            self.label_r4_1.place_forget()
            self.label_r4_2.place_forget()
            self.label_r4_3.place_forget()

            self.entry_r4.place_forget()
            self.entry_r4_1.place_forget()
            self.entry_r4_2.place_forget()
            self.entry_r4_3.place_forget()


    def tick_func4(self):
            self.calc.var1 = 4
            self.label_r4.place(x=15, y=80)
            self.label_r4_1.place(x=100, y=80)
            self.label_r4_2.place(x=170, y=80)
            self.label_r4_3.place(x=250, y=80)
            self.entry_r4.place(x=65, y=80)
            self.entry_r4_1.place(x=140, y=80)
            self.entry_r4_2.place(x=220, y=80)
            self.entry_r4_3.place(x=300, y=80)

            self.label_r2.place_forget()
            self.label_r2_1.place_forget()

            self.entry_r2.place_forget()
            self.entry_r2_1.place_forget()

            self.label_r3.place_forget()
            self.label_r3_1.place_forget()
            self.label_r3_2.place_forget()

            self.entry_r3.place_forget()
            self.entry_r3_1.place_forget()
            self.entry_r3_2.place_forget()

    def set_parallel(self):
        self.calc.var_p = True

    def set_series(self):
        self.calc.var_s = True

    def calculate(self):
        self.calc.result(self.entry_r2, self.entry_r2_1, self.entry_r3,
                    self.entry_r3_1, self.entry_r3_2, self.entry_r4,
                    self.entry_r4_1, self.entry_r4_2, self.entry_r4_3,
                    self.entry2, self.entry_total_resistance, self.entry_total_current)
        self.tick.deselect()
        self.tick1.deselect()

    def show_calcwindow(self):
        mycolor1 = "#6C6C6C"

        self.root1.configure(bg=mycolor1)

        self.label_entry = Label(self.root1, text='Number of resistors(Ohms):', bg=mycolor1, fg='white',
                            font=('Fixedsys', 10))
        self.label_entry.place(x=70, y=8)


        self.label_r2 = Label(self.root1, text='R1 =', bg=mycolor1, fg='white', font=('Fixedsys', 1))
        self.label_r2_1 = Label(self.root1, text='R2 =', bg=mycolor1, fg='white', font=('Fixedsys', 1))
        self.entry_r2 = Entry(self.root1, width=3)
        self.entry_r2_1 = Entry(self.root1, width=3)




        self.label_r3 = Label(self.root1, text='R1 =', bg=mycolor1, fg='white', font=('Fixedsys', 1))
        self.label_r3_1 = Label(self.root1, text='R2 =', bg=mycolor1, fg='white', font=('Fixedsys', 1))
        self.label_r3_2 = Label(self.root1, text='R3 =', bg=mycolor1, fg='white', font=('Fixedsys', 1))
        self.entry_r3 = Entry(self.root1, width=3)
        self.entry_r3_1 = Entry(self.root1, width=3)
        self.entry_r3_2 = Entry(self.root1, width=3)


        self.label_r4 = Label(self.root1, text='R1 =', bg=mycolor1, fg='white', font=('Fixedsys', 1))
        self.label_r4_1 = Label(self.root1, text='R2 =', bg=mycolor1, fg='white', font=('Fixedsys', 1))
        self.label_r4_2 = Label(self.root1, text='R3 =', bg=mycolor1, fg='white', font=('Fixedsys', 1))
        self.label_r4_3 = Label(self.root1, text='R4 =', bg=mycolor1, fg='white', font=('Fixedsys', 1))
        self.entry_r4 = Entry(self.root1, width=3)
        self.entry_r4_1 = Entry(self.root1, width=3)
        self.entry_r4_2 = Entry(self.root1, width=3)
        self.entry_r4_3 = Entry(self.root1, width=3)



        self.label_voltage = Label(self.root1, text='Input the supply voltage(Volts):', bg=mycolor1, fg='white',
                              font=('Fixedsys', 1))
        self.label_voltage.place(x=20, y=110)
        self.entry2 = Entry(self.root1, width=6)
        self.entry2.place(x=280, y=110)

        self.label_total_resistance = Label(self.root1, text='Input the total resistance(Ohms):', bg=mycolor1, fg='white',
                                       font=('Fixedsys', 1))
        self.label_total_resistance.place(x=20, y=150)
        self.entry_total_resistance = Entry(self.root1, width=6)
        self.entry_total_resistance.place(x=287, y=150)

        self.label_total_current = Label(self.root1, text='Input the total current(Amps):', bg=mycolor1, fg='white',
                                    font=('Fixedsys', 1))
        self.label_total_current.place(x=20, y=190)
        self.entry_total_current = Entry(self.root1, width=6)
        self.entry_total_current.place(x=263, y=190)


        self.tick = Checkbutton(self.root1, text='Series', bg=mycolor1, command=self.set_series)
        self.tick.place(x=50, y=240)

        self.tick1 = Checkbutton(self.root1, text='Parallel', bg=mycolor1, command=self.set_parallel)
        self.tick1.place(x=200, y=240)



        self.tick_r3 = Radiobutton(self.root1, text='3', bg=mycolor1,
                                   font=('Fixedsys', 1), command= self.tick_func3)

        self.tick_r3.place(x=205, y=35)
        self.tick_r4 = Radiobutton(self.root1, text='4', bg=mycolor1,
                                   font=('Fixedsys', 1), command=self.tick_func4)
        self.tick_r4.place(x=285, y=35)
        self.tick_r2 = Radiobutton(self.root1, text='2', bg=mycolor1,
                                   font=('Fixedsys', 1), command=self.tick_func2)
        self.tick_r2.place(x=120, y=35)
        self.tick_r5 = Radiobutton(self.root1, text='0', bg=mycolor1,
                                   command=self.tick_func0)
        self.tick_r5.place(x=40, y=35)
        self.button_go = Button(self.root1, text='CALCULATE!', bg="#6C6C6C", fg='white', font=('Fixedsys', 10),
                           command= self.calculate).place(x=108,y=270)